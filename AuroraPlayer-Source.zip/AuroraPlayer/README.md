# Aurora Player

A dark, pixel-inspired Android local music player starter project.

## Included in version 1

- Reads music stored on the device using Android's media library permission.
- Lists local audio tracks and filters by title or artist.
- Plays, pauses, skips forward/back, and seeks within the current track.
- Lyrics screen with per-track local saving.
- Google lyrics search shortcut for the selected track.
- Dark monochrome interface with mint accents and monospace typography.

## Build an APK on GitHub

1. Create a new repository on GitHub (public if you want to share the release page with friends).
2. Upload the contents of this folder to the repository's root. Keep the `.github/workflows/build-apk.yml` file.
3. Open the repository's **Actions** tab and select **Build Aurora Player APK**. Run it manually once, or push a commit to `main`/`master`.
4. When the workflow finishes, open the run and download **Aurora-Player-APK** under **Artifacts**.
5. To create a shareable release download, create and push a tag such as `v1.0.0`. The workflow will attach the APK to the GitHub Release.

## Build locally

Requires JDK 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- The app asks for audio-library permission when first opened. It does not upload or send your music anywhere; tracks are read locally through Android MediaStore.
- Lyrics are saved locally on the phone, associated with the selected track's MediaStore ID.
- This is an initial version. Playback currently runs inside the app; a persistent background playback service, lock-screen/media notification controls, embedded album-art display, playlists, and timed/scrolling lyrics are not included yet.
- The APK produced by this workflow is a debug-signed APK. It can be installed for testing and shared, but a production release should use a private signing key and a signed release build.
