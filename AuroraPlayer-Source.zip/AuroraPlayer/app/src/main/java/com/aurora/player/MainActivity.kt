package com.aurora.player

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

private data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : Activity() {
    private val bg = Color.rgb(23, 23, 25)
    private val panel = Color.rgb(39, 39, 42)
    private val mint = Color.rgb(70, 217, 198)
    private val white = Color.rgb(242, 242, 242)
    private val muted = Color.rgb(165, 165, 170)
    private val tracks = mutableListOf<Track>()
    private var shown = listOf<Track>()
    private var currentIndex = -1
    private var player: MediaPlayer? = null
    private var lyricsMode = false
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var playButton: TextView
    private lateinit var search: EditText
    private lateinit var seek: SeekBar
    private lateinit var timeLabel: TextView
    private lateinit var lyricsInput: EditText
    private val prefs by lazy { getSharedPreferences("lyrics", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildShell()
        requestAudioPermission()
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadTracks()
        else ActivityCompat.requestPermissions(this, arrayOf(permission), 44)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadTracks()
        else showPermissionMessage()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(14), dp(18), dp(10)) }
        setContentView(root)
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        header.addView(label("AURORA PLAYER", 25, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("✦", 28, mint, true))
        root.addView(header)
        root.addView(label("YOUR MUSIC. YOUR SPACE.", 11, muted).apply { setPadding(0, dp(3), 0, dp(14)) })

        val hero = TextView(this).apply {
            text = "  ✦       A U R O R A\n\n       MUSIC LIBRARY\n\n  NIGHT MODE  •  LOCAL AUDIO"
            textSize = 17f; typeface = android.graphics.Typeface.MONOSPACE; setTextColor(mint)
            gravity = Gravity.CENTER; setPadding(dp(10), dp(20), dp(10), dp(20)); setBackgroundColor(panel)
        }
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(142)))
        val nowCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(10)); setBackgroundColor(panel) }
        val nowHeading = label("NOW PLAYING", 11, mint, true)
        nowCard.addView(nowHeading)
        nowTitle = label("Choose a track", 17, white, true)
        nowArtist = label("Your phone's music will appear below", 12, muted)
        nowCard.addView(nowTitle); nowCard.addView(nowArtist)
        seek = SeekBar(this).apply { progressTintList = android.content.res.ColorStateList.valueOf(mint); thumbTintList = android.content.res.ColorStateList.valueOf(mint) }
        nowCard.addView(seek)
        timeLabel = label("00:00  /  00:00", 10, muted)
        nowCard.addView(timeLabel)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        controls.addView(action("|◀") { playPrevious() })
        playButton = action("▶") { togglePlayback() }
        controls.addView(playButton)
        controls.addView(action("▶|") { playNext() })
        nowCard.addView(controls)
        root.addView(nowCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(8)) }
        tabs.addView(action("TRACKS") { lyricsMode = false; renderContent() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(action("LYRICS") { lyricsMode = true; renderContent() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(tabs)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) timeLabel.text = "${formatTime(p.toLong())}  /  ${formatTime(player?.duration?.toLong() ?: 0)}" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { player?.seekTo(s?.progress ?: 0) }
        })
        renderContent()
    }

    private fun showPermissionMessage() {
        content.removeAllViews()
        content.addView(label("Allow audio access to show music stored on your phone.", 14, white))
        content.addView(action("TRY AGAIN") { requestAudioPermission() })
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                tracks.add(Track(id, cursor.getString(titleCol) ?: "Unknown track", cursor.getString(artistCol) ?: "Unknown artist", uri, cursor.getLong(durationCol)))
            }
        }
        renderContent()
    }

    private fun renderContent() {
        content.removeAllViews()
        if (lyricsMode) { renderLyrics(); return }
        search = EditText(this).apply {
            hint = "Search tracks or artists..."; setHintTextColor(muted); setTextColor(white); textSize = 14f
            setSingleLine(true); setPadding(dp(12), 0, dp(12), 0); setBackgroundColor(panel)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderTrackList(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(46)))
        val count = label("  ${tracks.size} TRACKS ON THIS DEVICE", 10, muted)
        content.addView(count, LinearLayout.LayoutParams(-1, dp(30)))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        list.tag = "track_list"
        renderTrackList("")
    }

    private fun renderTrackList(query: String) {
        val scroll = content.getChildAt(2) as? ScrollView ?: return
        val list = scroll.getChildAt(0) as? LinearLayout ?: return
        list.removeAllViews()
        shown = tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
        if (shown.isEmpty()) {
            list.addView(label(if (tracks.isEmpty()) "No music found. Add audio files to your phone and refresh." else "No matching tracks.", 13, muted).apply { setPadding(dp(8), dp(18), 0, 0) })
        }
        shown.forEach { track ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(8), dp(10)); setBackgroundColor(panel) }
            val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            textBox.addView(label(track.title, 14, white, true))
            textBox.addView(label(track.artist, 11, muted))
            row.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label("${formatTime(track.duration)}   ▶", 11, mint))
            row.setOnClickListener { playTrack(track) }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }
    }

    private fun renderLyrics() {
        val track = tracks.getOrNull(currentIndex)
        content.addView(label("LYRICS / ${track?.title ?: "NO TRACK SELECTED"}", 12, mint, true))
        lyricsInput = EditText(this).apply {
            hint = "Paste or write the lyrics here..."; setHintTextColor(muted); setTextColor(white)
            gravity = Gravity.TOP; textSize = 14f; setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(panel)
            minLines = 8
            if (track != null) setText(prefs.getString(track.id.toString(), "") ?: "")
            else isEnabled = false
        }
        content.addView(lyricsInput, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        content.addView(action("SAVE LYRICS") {
            if (track != null) { prefs.edit().putString(track.id.toString(), lyricsInput.text.toString()).apply(); Toast.makeText(this, "Lyrics saved", Toast.LENGTH_SHORT).show() }
        })
        content.addView(action("SEARCH LYRICS ON GOOGLE") {
            if (track != null) {
                val q = Uri.encode("${track.title} ${track.artist} lyrics")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")))
            } else Toast.makeText(this, "Play a track first", Toast.LENGTH_SHORT).show()
        })
        content.addView(label("Tip: copy the lyrics from your browser, return here, paste them, then save.", 10, muted))
    }

    private fun playTrack(track: Track) {
        val index = tracks.indexOfFirst { it.id == track.id }
        currentIndex = index
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(this@MainActivity, track.uri)
            setOnPreparedListener { mp -> mp.start(); playButton.text = "Ⅱ"; seek.max = mp.duration; nowTitle.text = track.title; nowArtist.text = track.artist; updateProgress() }
            setOnCompletionListener { playNext() }
            setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "Can't play this audio file", Toast.LENGTH_SHORT).show(); true }
            prepareAsync()
        }
        nowTitle.text = track.title
        nowArtist.text = track.artist
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) { tracks.getOrNull(currentIndex.coerceAtLeast(0))?.let { playTrack(it) }; return }
        if (p.isPlaying) { p.pause(); playButton.text = "▶" } else { p.start(); playButton.text = "Ⅱ"; updateProgress() }
    }
    private fun playNext() { if (tracks.isNotEmpty()) playTrack(tracks[(currentIndex + 1).mod(tracks.size)]) }
    private fun playPrevious() { if (tracks.isNotEmpty()) playTrack(tracks[(currentIndex - 1).let { if (it < 0) tracks.lastIndex else it }]) }
    private fun updateProgress() {
        val p = player ?: return
        if (p.isPlaying) {
            seek.progress = p.currentPosition
            timeLabel.text = "${formatTime(p.currentPosition.toLong())}  /  ${formatTime(p.duration.toLong())}"
            seek.postDelayed({ if (player === p && p.isPlaying) updateProgress() }, 500)
        }
    }

    private fun action(text: String, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 13f; typeface = android.graphics.Typeface.MONOSPACE; setTextColor(white)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(panel); isClickable = true; isFocusable = true
        setOnClickListener { click() }
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); typeface = android.graphics.Typeface.MONOSPACE
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun formatTime(ms: Long): String { val sec = (ms / 1000).coerceAtLeast(0); return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60) }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
